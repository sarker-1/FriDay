
FriDay AI – Complete Drag & Drop Project

1. Import this folder into any AI App Builder / Android Studio
2. Replace logic using Gemini or other AI tools
3. UI is clean, minimal, voice-first

No UI clutter by design.
